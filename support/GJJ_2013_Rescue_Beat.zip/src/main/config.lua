application = 
{
	content = 
	{
		--fps = 60,
		width = 768,
		height = 1024, 
		scale = "zoomEven",
		--scale = "letterbox",
		--yAlign = "top",
		--xAlign = "left"
	}
}